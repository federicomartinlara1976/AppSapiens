#!/bin/bash

java -jar mdval-1.0.0-SNAPSHOT.jar
